import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { render } from 'react-dom';
import { UnControlled as CodeEditor } from 'react-simple-code-editor';
import { highlight, languages } from 'prismjs';
import 'prismjs/components/prism-markup';
import 'prismjs/components/prism-css';
import 'prismjs/themes/prism.css';

function App() {
  const [snippets, setSnippets] = useState([]);
  const [form, setForm] = useState({ 
    title: '', 
    html: '<button>Click Me</button>', 
    css: 'button { background: #3498db; color: white; padding: 10px 20px; }' 
  });

  useEffect(() => {
    axios.get('http://localhost:5000/api/snippets')
      .then(res => setSnippets(res.data));
  }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await axios.post('http://localhost:5000/api/snippets', form);
    setSnippets([res.data, ...snippets]);
  };

  const copyToClipboard = (html, css) => {
    navigator.clipboard.writeText(`${html}\n<style>\n${css}\n</style>`);
    alert('Code copied to clipboard!');
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-blue-500">HTML & CSS Snippet Sharing</h1>
      
      {/* Snippet Creation Form */}
      <form onSubmit={handleSubmit} className="mb-8 p-4 bg-gray-50 rounded-lg">
        <div className="mb-4">
          <label className="block mb-2 font-medium">Title</label>
          <input 
            name="title"
            value={form.title}
            onChange={handleChange}
            className="w-full p-2 border rounded"
            placeholder="Button with hover effect"
            required
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block mb-2 font-medium">HTML Code</label>
            <CodeEditor
              value={form.html}
              onValueChange={code => setForm({...form, html: code})}
              highlight={code => highlight(code, languages.html, 'html')}
              padding={10}
              className="border rounded"
              style={{ fontFamily: '"Fira code", "Fira Mono", monospace', fontSize: 14 }}
            />
          </div>
          
          <div>
            <label className="block mb-2 font-medium">CSS Code</label>
            <CodeEditor
              value={form.css}
              onValueChange={code => setForm({...form, css: code})}
              highlight={code => highlight(code, languages.css, 'css')}
              padding={10}
              className="border rounded"
              style={{ fontFamily: '"Fira code", "Fira Mono", monospace', fontSize: 14 }}
            />
          </div>
        </div>
        
        <button 
          type="submit" 
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Share Snippet
        </button>
      </form>

      {/* Snippet Display */}
      <h2 className="text-2xl font-semibold mb-4">Community Snippets</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {snippets.map(snippet => (
          <div key={snippet._id} className="border rounded-lg overflow-hidden shadow-md">
            <div className="p-4">
              <h3 className="text-xl font-medium mb-2">{snippet.title}</h3>
              
              <div className="mb-3">
                <h4 className="font-medium mb-1">HTML:</h4>
                <pre className="bg-gray-100 p-2 rounded text-sm overflow-x-auto">{snippet.html}</pre>
              </div>
              
              <div className="mb-4">
                <h4 className="font-medium mb-1">CSS:</h4>
                <pre className="bg-gray-100 p-2 rounded text-sm overflow-x-auto">{snippet.css}</pre>
              </div>
              
              <button 
                onClick={() => copyToClipboard(snippet.html, snippet.css)}
                className="w-full bg-green-500 text-white py-1 rounded hover:bg-green-600"
              >
                Copy Code
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
